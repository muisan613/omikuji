<div class="swiper swipe-lp">
  <div class="swiper-wrapper">
    <section class="swiper-slide" style="background:#f0f0f0"><h2>Hero</h2><p>キャッチコピー</p></section>
    <section class="swiper-slide" style="background:#fff"><h2>Benefit</h2><p>メリット</p></section>
    <section class="swiper-slide" style="background:#eee"><h2>CTA</h2><p>お申し込みはこちら</p></section>
  </div>
  <div class="swiper-pagination"></div>
</div>
