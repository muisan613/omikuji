
# omikuji (WordPress × Stripe 電子おみくじ)
...（略：使い方はGitHub上で参照してください。ここではコードのみ用意します）
